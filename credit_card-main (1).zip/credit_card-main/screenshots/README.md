# Screenshots

This folder stores generated plots and UI screenshots.

After running:

```bash
python train_model.py
```

you should see:

- approval distribution
- count plot
- age distribution
- income distribution
- income box plot
- correlation heatmap
- pair plot
- histograms
- confusion matrices
- ROC curves

Add UI screenshots here after running the Flask app locally.
