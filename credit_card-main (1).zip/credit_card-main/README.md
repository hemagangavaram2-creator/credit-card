# Credit Card Approval Prediction System

A complete machine learning and Flask web project that predicts whether a credit card application is likely to be **Approved** or **Rejected**.

## Project Overview

This project includes exploratory data analysis, preprocessing, multiple machine learning models, automatic model selection, saved model artifacts, a responsive Flask web application, and an IBM Watson Machine Learning deployment guide.

## Problem Statement

Banks and financial institutions receive many credit card applications. Manual screening can be slow and inconsistent. This system uses applicant profile, income, employment, housing, credit history, and loan information to estimate approval probability.

## Dataset

The project includes `dataset/credit_card.csv`, a small ready-to-run sample with credit-card-approval-style fields. For a larger public dataset, use Kaggle's commonly used **Credit Card Approval Prediction** dataset containing `application_record.csv` and `credit_record.csv`, then map or engineer the fields into the same schema.

Required target column:

- `Approved`: `Approved` or `Rejected`

## Technologies Used

- Python
- Flask
- HTML, CSS, Bootstrap, JavaScript
- Pandas, NumPy
- Matplotlib, Seaborn
- Scikit-learn
- XGBoost
- Joblib
- IBM Watson Machine Learning

## Installation

```bash
cd CreditCardApproval
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt