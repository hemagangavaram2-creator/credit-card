const form = document.getElementById("predictionForm");
const predictButton = document.getElementById("predictBtn");

function setLoading(isLoading) {
    if (!predictButton) {
        return;
    }

    const buttonText = predictButton.querySelector(".btn-text");
    const spinner = predictButton.querySelector(".spinner-border");

    predictButton.disabled = isLoading;
    buttonText.classList.toggle("d-none", isLoading);
    spinner.classList.toggle("d-none", !isLoading);
}

function validateNumericRanges() {
    const numericInputs = form.querySelectorAll("input[type='number']");
    let isValid = true;

    numericInputs.forEach((input) => {
        const value = Number(input.value);
        const min = input.min === "" ? Number.NEGATIVE_INFINITY : Number(input.min);
        const max = input.max === "" ? Number.POSITIVE_INFINITY : Number(input.max);

        if (Number.isNaN(value) || value < min || value > max) {
            input.setCustomValidity("Please enter a value within the accepted range.");
            isValid = false;
        } else {
            input.setCustomValidity("");
        }
    });

    return isValid;
}

if (form) {
    form.addEventListener("submit", (event) => {
        validateNumericRanges();

        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
            setLoading(false);
        } else {
            setLoading(true);
        }

        form.classList.add("was-validated");
    });
}