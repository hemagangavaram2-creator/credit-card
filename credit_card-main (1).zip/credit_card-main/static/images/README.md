# Images

Static images for the Flask application can be stored here.

The current UI uses remote Unsplash banking-themed background images through CSS. For offline use, download approved images into this folder and update `static/css/style.css`.
