# Notebooks

Use this folder for exploratory notebooks.

Recommended notebook:

- `credit_card_approval_eda_training.ipynb`

The main production training logic is maintained in `train_model.py` so it can be rerun from the command line and used in deployment pipelines.
