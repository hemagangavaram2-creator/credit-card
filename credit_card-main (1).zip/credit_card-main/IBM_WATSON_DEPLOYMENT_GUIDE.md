# IBM Watson Machine Learning Deployment Guide

## 1. Create an IBM Cloud Account

1. Visit `https://cloud.ibm.com`.
2. Create an account or sign in.
3. Confirm billing or Lite plan access.

## 2. Create Watson Studio

1. Open IBM Cloud catalog.
2. Search for **Watson Studio**.
3. Create a Watson Studio service.
4. Launch Watson Studio.

## 3. Create Cloud Object Storage

1. In Watson Studio, create a new project.
2. When prompted, create or attach **IBM Cloud Object Storage**.
3. Use this storage to keep notebooks, model files, and datasets.

## 4. Upload Notebook and Dataset

1. Upload `train_model.py` logic into a Watson Studio notebook.
2. Upload `dataset/credit_card.csv`.
3. Install project dependencies inside the notebook environment when required.

## 5. Train and Save Model

Train the selected model and save it with Joblib:

```python
import joblib

joblib.dump(best_pipeline, "model.pkl")