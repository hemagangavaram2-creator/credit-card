"""Train and evaluate credit card approval prediction models."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder, OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier

try:
    from xgboost import XGBClassifier
except ImportError:
    XGBClassifier = None


BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "dataset" / "credit_card.csv"
MODEL_DIR = BASE_DIR / "models"
SCREENSHOT_DIR = BASE_DIR / "screenshots"

TARGET = "Approved"

NUMERIC_FEATURES = [
    "Age",
    "Annual Income",
    "Employment Years",
    "Number of Children",
    "Family Members",
]

CATEGORICAL_FEATURES = [
    "Gender",
    "Income Type",
    "Education",
    "Marital Status",
    "Housing Type",
    "Credit History",
    "Loan Status",
    "Occupation",
]

FEATURE_COLUMNS = NUMERIC_FEATURES + CATEGORICAL_FEATURES


def load_dataset(path: Path = DATA_PATH) -> pd.DataFrame:
    """Load the credit card approval dataset."""
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found at {path}")
    return pd.read_csv(path)


def show_eda_summary(df: pd.DataFrame) -> None:
    """Print key EDA information to the console."""
    print("\n================ EDA SUMMARY ================")
    print(f"Shape: {df.shape}")

    print("\nInfo:")
    df.info()

    print("\nMissing values:")
    print(df.isnull().sum())

    print(f"\nDuplicate values: {df.duplicated().sum()}")

    print("\nStatistical summary:")
    print(df.describe(include="all"))


def save_plot(path: Path) -> None:
    """Save the active matplotlib figure and close it."""
    plt.tight_layout()
    plt.savefig(path, dpi=160, bbox_inches="tight")
    plt.close()


def generate_visualizations(df: pd.DataFrame) -> None:
    """Generate EDA plots using Seaborn and Matplotlib."""
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid", palette="Set2")

    plt.figure(figsize=(8, 5))
    sns.countplot(data=df, x=TARGET)
    plt.title("Approval Distribution")
    save_plot(SCREENSHOT_DIR / "approval_distribution.png")

    plt.figure(figsize=(8, 5))
    sns.histplot(data=df, x="Age", hue=TARGET, kde=True, bins=12)
    plt.title("Age Distribution")
    save_plot(SCREENSHOT_DIR / "age_distribution.png")

    plt.figure(figsize=(9, 5))
    sns.boxplot(data=df, x=TARGET, y="Annual Income")
    plt.title("Annual Income Box Plot")
    save_plot(SCREENSHOT_DIR / "income_boxplot.png")

    plt.figure(figsize=(9, 5))
    sns.histplot(data=df, x="Annual Income", hue=TARGET, kde=True, bins=12)
    plt.title("Income Distribution")
    save_plot(SCREENSHOT_DIR / "income_distribution.png")

    plt.figure(figsize=(10, 7))
    corr_df = df[NUMERIC_FEATURES].corr(numeric_only=True)
    sns.heatmap(corr_df, annot=True, cmap="coolwarm", linewidths=0.5)
    plt.title("Correlation Heatmap")
    save_plot(SCREENSHOT_DIR / "correlation_heatmap.png")

    pair_plot = sns.pairplot(df[NUMERIC_FEATURES + [TARGET]], hue=TARGET)
    pair_plot.fig.suptitle("Pair Plot", y=1.02)
    pair_plot.savefig(SCREENSHOT_DIR / "pair_plot.png", dpi=160, bbox_inches="tight")
    plt.close("all")

    df[NUMERIC_FEATURES].hist(figsize=(12, 8), bins=12)
    plt.suptitle("Feature Histograms")
    save_plot(SCREENSHOT_DIR / "histograms.png")

    plt.figure(figsize=(10, 5))
    sns.countplot(data=df, x="Income Type", hue=TARGET)
    plt.title("Count Plot by Income Type")
    plt.xticks(rotation=25, ha="right")
    save_plot(SCREENSHOT_DIR / "count_plot_income_type.png")


def preprocess_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Clean missing values, duplicates, and outliers before modeling."""
    clean_df = df.copy()
    clean_df = clean_df.drop_duplicates()

    for column in NUMERIC_FEATURES:
        clean_df[column] = pd.to_numeric(clean_df[column], errors="coerce")
        clean_df[column] = clean_df[column].fillna(clean_df[column].median())

        q1 = clean_df[column].quantile(0.25)
        q3 = clean_df[column].quantile(0.75)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr
        clean_df[column] = clean_df[column].clip(lower=lower, upper=upper)

    for column in CATEGORICAL_FEATURES + [TARGET]:
        clean_df[column] = clean_df[column].fillna(clean_df[column].mode()[0])
        clean_df[column] = clean_df[column].astype(str).str.strip()

    return clean_df


def build_preprocessor() -> ColumnTransformer:
    """Create preprocessing pipeline with scaling and one-hot encoding."""
    numeric_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_pipeline = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )

    return ColumnTransformer(
        transformers=[
            ("numeric", numeric_pipeline, NUMERIC_FEATURES),
            ("categorical", categorical_pipeline, CATEGORICAL_FEATURES),
        ]
    )


def get_models() -> dict[str, Any]:
    """Return all candidate models."""
    models: dict[str, Any] = {
        "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42),
        "Decision Tree": DecisionTreeClassifier(max_depth=6, random_state=42),
        "Random Forest": RandomForestClassifier(
            n_estimators=250,
            max_depth=8,
            random_state=42,
            class_weight="balanced",
        ),
    }

    if XGBClassifier is not None:
        models["XGBoost"] = XGBClassifier(
            n_estimators=200,
            max_depth=4,
            learning_rate=0.05,
            subsample=0.9,
            colsample_bytree=0.9,
            eval_metric="logloss",
            random_state=42,
        )

    return models


def evaluate_model(
    name: str,
    pipeline: Pipeline,
    x_test: pd.DataFrame,
    y_test: np.ndarray,
    label_encoder: LabelEncoder,
) -> dict[str, Any]:
    """Evaluate one model and save confusion matrix and ROC curve."""
    predictions = pipeline.predict(x_test)
    probabilities = pipeline.predict_proba(x_test)[:, 1]

    metrics = {
        "Model": name,
        "Accuracy": accuracy_score(y_test, predictions),
        "Precision": precision_score(y_test, predictions, zero_division=0),
        "Recall": recall_score(y_test, predictions, zero_division=0),
        "F1 Score": f1_score(y_test, predictions, zero_division=0),
        "ROC AUC": roc_auc_score(y_test, probabilities),
    }

    print(f"\n================ {name} ================")
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, predictions))

    print("\nClassification Report:")
    print(classification_report(y_test, predictions, target_names=label_encoder.classes_))

    ConfusionMatrixDisplay.from_predictions(
        y_test,
        predictions,
        display_labels=label_encoder.classes_,
        cmap="Blues",
    )
    plt.title(f"{name} Confusion Matrix")
    save_plot(SCREENSHOT_DIR / f"{name.lower().replace(' ', '_')}_confusion_matrix.png")

    fpr, tpr, _ = roc_curve(y_test, probabilities)
    plt.figure(figsize=(7, 5))
    plt.plot(fpr, tpr, label=f"{name} AUC={metrics['ROC AUC']:.3f}")
    plt.plot([0, 1], [0, 1], linestyle="--", color="gray")
    plt.xlabel("False Positive Rate")
    plt.ylabel("True Positive Rate")
    plt.title(f"{name} ROC Curve")
    plt.legend()
    save_plot(SCREENSHOT_DIR / f"{name.lower().replace(' ', '_')}_roc_curve.png")

    return metrics


def train_and_select_best_model() -> None:
    """Train all models, compare metrics, and save the best pipeline."""
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)

    df = load_dataset()
    show_eda_summary(df)
    generate_visualizations(df)

    clean_df = preprocess_dataframe(df)

    x = clean_df[FEATURE_COLUMNS]

    label_encoder = LabelEncoder()
    y = label_encoder.fit_transform(clean_df[TARGET])

    x_train, x_test, y_train, y_test = train_test_split(
        x,
        y,
        test_size=0.2,
        random_state=42,
        stratify=y,
    )

    results = []
    trained_pipelines = {}

    for name, model in get_models().items():
        pipeline = Pipeline(
            steps=[
                ("preprocessor", build_preprocessor()),
                ("classifier", model),
            ]
        )

        pipeline.fit(x_train, y_train)
        metrics = evaluate_model(name, pipeline, x_test, y_test, label_encoder)

        results.append(metrics)
        trained_pipelines[name] = pipeline

    comparison_df = pd.DataFrame(results).sort_values(
        by=["F1 Score", "ROC AUC", "Accuracy"],
        ascending=False,
    )

    print("\n================ MODEL COMPARISON ================")
    print(comparison_df.to_string(index=False))

    best_model_name = comparison_df.iloc[0]["Model"]
    best_pipeline = trained_pipelines[best_model_name]

    joblib.dump(best_pipeline, BASE_DIR / "model.pkl")
    joblib.dump(best_pipeline.named_steps["preprocessor"], BASE_DIR / "scaler.pkl")
    joblib.dump({"target": label_encoder}, BASE_DIR / "label_encoders.pkl")
    joblib.dump(best_pipeline, MODEL_DIR / "best_model.pkl")

    comparison_df.to_csv(MODEL_DIR / "model_comparison.csv", index=False)

    metadata = {
        "best_model": best_model_name,
        "feature_columns": FEATURE_COLUMNS,
        "numeric_features": NUMERIC_FEATURES,
        "categorical_features": CATEGORICAL_FEATURES,
        "target_classes": label_encoder.classes_.tolist(),
    }

    (MODEL_DIR / "metadata.json").write_text(
        json.dumps(metadata, indent=4),
        encoding="utf-8",
    )

    print(f"\nBest model saved: {best_model_name}")


if __name__ == "__main__":
    train_and_select_best_model()