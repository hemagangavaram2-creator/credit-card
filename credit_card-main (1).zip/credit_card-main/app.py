"""Flask application for credit card approval prediction."""

from __future__ import annotations

from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, render_template, request


BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model.pkl"
ENCODER_PATH = BASE_DIR / "label_encoders.pkl"

FEATURE_COLUMNS = [
    "Age",
    "Annual Income",
    "Employment Years",
    "Number of Children",
    "Family Members",
    "Gender",
    "Income Type",
    "Education",
    "Marital Status",
    "Housing Type",
    "Credit History",
    "Loan Status",
    "Occupation",
]

NUMERIC_FIELDS = [
    "Age",
    "Annual Income",
    "Employment Years",
    "Number of Children",
    "Family Members",
]


app = Flask(__name__)


def load_artifacts():
    """Load trained model and label encoder artifacts."""
    if not MODEL_PATH.exists() or not ENCODER_PATH.exists():
        raise FileNotFoundError(
            "Model artifacts are missing. Run `python train_model.py` first."
        )
    model = joblib.load(MODEL_PATH)
    label_encoders = joblib.load(ENCODER_PATH)
    return model, label_encoders["target"]


def build_input_dataframe(form_data) -> pd.DataFrame:
    """Convert HTML form data into one prediction row."""
    row = {}
    for feature in FEATURE_COLUMNS:
        value = form_data.get(feature, "").strip()
        if feature in NUMERIC_FIELDS:
            row[feature] = float(value)
        else:
            row[feature] = value
    return pd.DataFrame([row], columns=FEATURE_COLUMNS)


@app.route("/", methods=["GET"])
def home():
    """Render prediction form."""
    return render_template("index.html")


@app.route("/predict", methods=["POST"])
def predict():
    """Predict approval status and display the result."""
    try:
        model, target_encoder = load_artifacts()
        input_df = build_input_dataframe(request.form)
        prediction = model.predict(input_df)[0]
        probabilities = model.predict_proba(input_df)[0]

        result = target_encoder.inverse_transform([prediction])[0]
        confidence = round(float(max(probabilities)) * 100, 2)

        return render_template(
            "result.html",
            result=result,
            confidence=confidence,
            applicant=input_df.iloc[0].to_dict(),
            is_approved=result.lower() == "approved",
        )
    except Exception as exc:
        return render_template(
            "result.html",
            result="Prediction Error",
            confidence=0,
            applicant={},
            is_approved=False,
            error=str(exc),
        )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)